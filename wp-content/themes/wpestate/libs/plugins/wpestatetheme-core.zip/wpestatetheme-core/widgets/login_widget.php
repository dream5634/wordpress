<?php
class Login_widget extends WP_Widget {
	function __construct(){
	//function Login_widget(){
		$widget_ops = array('classname' => 'loginwd_sidebar boxed_widget', 'description' => 'Put the login & register form on sidebar');
		$control_ops = array('id_base' => 'login_widget');
		//$this->WP_Widget('login_widget', 'Wp Estate: Login & Register', $widget_ops, $control_ops);
                parent::__construct('login_widget', 'Wp Estate: Login & Register', $widget_ops, $control_ops);
	}
	
	function form($instance){
		$defaults = array();
		$instance = wp_parse_args((array) $instance, $defaults);
		$display='';
		print $display;
	}


	function update($new_instance, $old_instance){
		$instance = $old_instance;
		return $instance;
	}



	function widget($args, $instance){
		extract($args);
                $display='';
		global $post;
              
		print $before_widget;
                $facebook_status    =   esc_html( get_option('wp_estate_facebook_login','') );
                $google_status      =   esc_html( get_option('wp_estate_google_login','') );
                $yahoo_status       =   esc_html( get_option('wp_estate_yahoo_login','') );
		$mess='';
		$display.='
                <div class="login_sidebar">
                    <h3 class="widget-title-sidebar"  id="login-div-title">'.esc_html__('Login','wpestatetheme-core').'</h3>
                    <div class="login_form" id="login-div">
                        <div class="loginalert" id="login_message_area_wd" >'.$mess.'</div>
                            
                        <input type="text" class="form-control" name="log" id="login_user_wd" placeholder="'.esc_html__('Username','wpestatetheme-core').'"/>
                        <input type="password" class="form-control" name="pwd" id="login_pwd_wd" placeholder="'.esc_html__('Password','wpestatetheme-core').'"/>                       
                        <input type="hidden" name="loginpop" id="loginpop_wd" value="0">
                      
                        <input type="hidden" id="security-login" name="security-login" value="'. estate_create_onetime_nonce( 'login_ajax_nonce' ).'">
       
                   
                        <button class="wpresidence_button" id="wp-login-but-wd" >'.esc_html__('Login','wpestatetheme-core').'</button>
                        
                        <div class="login-links">
                            <a href="#" id="widget_register_sw">'.esc_html__('Register here!','wpestatetheme-core').'</a>
                            <a href="#" id="forgot_pass_widget">'.esc_html__('Forgot Password?','wpestatetheme-core').'</a>';
                        if($facebook_status=='yes'){
                            $display.='<div id="facebookloginsidebar" data-social="facebook">'.esc_html__('Login with Facebook','wpestatetheme-core').'</div>';
                        }
                        if($google_status=='yes'){
                            $display.='<div id="googleloginsidebar" data-social="google">'.esc_html__('Login with Google','wpestatetheme-core').'</div>';
                        }
                        if($yahoo_status=='yes'){
                            $display.='<div id="yahoologinsidebar" data-social="yahoo">'.esc_html__('Login with Yahoo','wpestatetheme-core').'</div>';
                        }
                
                   
                    $display.='
                        </div>    
                    </div>
                
              <h3 class="widget-title-sidebar"  id="register-div-title">'.esc_html__('Register','wpestatetheme-core').'</h3>
                <div class="login_form" id="register-div">
                    <div class="loginalert" id="register_message_area_wd" ></div>
                    <input type="text" name="user_login_register" id="user_login_register_wd" class="form-control" placeholder="'.esc_html__('Username','wpestatetheme-core').'"/>
                    <input type="text" name="user_email_register" id="user_email_register_wd" class="form-control" placeholder="'.esc_html__('Email','wpestatetheme-core').'"  />';
                    
                    $enable_user_pass_status= esc_html ( get_option('wp_estate_enable_user_pass','') );
                    if($enable_user_pass_status == 'yes'){
                        $display.= ' <input type="password" name="user_password_wd" id="user_password_wd" class="form-control" placeholder="'.esc_html__('Password','wpestatetheme-core').'"/>
                        <input type="password" name="user_password_retype_wd" id="user_password_wd_retype" class="form-control" placeholder="'.esc_html__('Retype Password','wpestatetheme-core').'"  />
                        ';
                    }
                    
                    $display.='<input type="checkbox" name="terms" id="user_terms_register_wd"><label id="user_terms_register_wd_label" for="user_terms_register_wd">'.esc_html__('I agree with ','wpestatetheme-core').'<a href="'.wpestate_get_terms_links().'" target="_blank" id="user_terms_register_topbar_link">'.esc_html__('terms & conditions','wpestatetheme-core').'</a> </label>';
                    
                    if(get_option('wp_estate_use_captcha','')=='yes'){
                        $display.= '<div id="widget_register_menu"  style="float:left;transform:scale(0.75);-webkit-transform:scale(0.75);transform-origin:0 0;-webkit-transform-origin:0 0;"></div>';
                    }
                                
                    
                    if($enable_user_pass_status != 'yes'){ 
                        $display.='<p id="reg_passmail">'.esc_html__('A password will be e-mailed to you','wpestatetheme-core').'</p>';
                    }
                    
                    //wp_nonce_field( 'register_ajax_nonce', 'security-register',false,false ).'
                    $display.= '  
                    <input type="hidden" id="security-register" name="security-register" value="'.estate_create_onetime_nonce( 'register_ajax_nonce' ).'">
           
                    <button class="wpresidence_button" id="wp-submit-register_wd">'.esc_html__('Register','wpestatetheme-core').'</button>

                    <div class="login-links">
                        <a href="#" id="widget_login_sw">'.esc_html__('Back to Login','wpestatetheme-core').'</a>                       
                    </div>   
                 </div>
                </div>
                <h3 class="widget-title-sidebar"  id="forgot-div-title_shortcode">'. esc_html__('Reset Password','wpestatetheme-core').'</h3>
                <div class="login_form" id="forgot-pass-div_shortcode">
                    <div class="loginalert" id="forgot_pass_area_shortcode"></div>
                    <div class="loginrow">
                            <input type="text" class="form-control" name="forgot_email" id="forgot_email_shortcode" placeholder="'.esc_html__('Enter Your Email Address','wpestatetheme-core').'" size="20" />
                    </div>
                    '. wp_nonce_field( 'login_ajax_nonce_forgot_wd', 'security-login-forgot_wd',true).'  
                    <input type="hidden" id="postid" value="0">    
                    <button class="wpresidence_button" id="wp-forgot-but_shortcode" name="forgot" >'.esc_html__('Reset Password','wpestatetheme-core').'</button>
                    <div class="">
                    <a href="#" id="return_login_shortcode">'.esc_html__('Return to Login','wpestatetheme-core').'</a>
                    </div>
                </div>
            ';
                
                
                $current_user = wp_get_current_user();
                $userID                 =   $current_user->ID;
                $user_login             =   $current_user->user_login;
                $user_email             =   get_the_author_meta( 'user_email' , $userID );
                
                $activeprofile= $activedash = $activeadd = $activefav ='';
                
                $add_link               =   wpestate_get_dasboard_add_listing();
                $dash_profile           =   wpestate_get_dashboard_profile_link(); 
                $dash_link              =   wpestate_get_dashboard_link();
                $dash_favorite          =   wpestate_get_dashboard_favorites();
                $dash_searches          =   wpestate_get_searches_link();
                $home_url               =   esc_url( home_url('/') );
                $dash_invoices          =   wpestate_get_invoice_link();
                $logged_display='
                    <h3 class="widget-title-sidebar" >'.esc_html__('Hello ','wpestatetheme-core'). ' '. $user_login .'  </h3>
                    
                    <ul class="wd_user_menu">';
                    if($home_url!=$dash_profile){
                        $logged_display.='<li> <a href="'.$dash_profile.'"  class="'.$activeprofile.'">'.esc_html__('My Profile','wpestatetheme-core').'</a> </li>';
                    }
                    if($home_url!=$dash_link){
                        $logged_display.=' <li> <a href="'.$dash_link.'"     class="'.$activedash.'">'.esc_html__('My Properties List','wpestatetheme-core').'</a> </li>';
                    }
                    if($home_url!=$add_link){
                        $logged_display.=' <li> <a href="'.$add_link.'"      class="'.$activeadd.'">'. esc_html__('Add New Property','wpestatetheme-core').'</a> </li>';
                    }
                    if($home_url!=$dash_favorite){
                        $logged_display.=' <li> <a href="'.$dash_favorite.'" class="'.$activefav.'">'.esc_html__('Favorites','wpestatetheme-core').'</a> </li>';
                    }
                    if($home_url!=$dash_searches){
                        $logged_display.=' <li> <a href="'.$dash_searches.'" class="'.$activefav.'">'.esc_html__('Saved Searches','wpestatetheme-core').'</a> </li>';
                    } 
                    if($home_url!=$dash_invoices){
                        $logged_display.=' <li> <a href="'.$dash_invoices.'" class="'.$activefav.'">'.esc_html__('My Invoices','wpestatetheme-core').'</a> </li>';
                    }
                    
                       
                        $logged_display.=' <li> <a href="'.wp_logout_url( esc_url( home_url('/') )).'" title="Logout">'.esc_html__('Log Out','wpestatetheme-core').'</a> </li>   
                    </ul>
                ';
                
               if ( is_user_logged_in() ) {                   
                  print $logged_display;
               }else{
                  print $display; 
               }
               print $after_widget;
	}

}

?>