<?php
class Featured_widget extends WP_Widget {
	function __construct(){
	//function Featured_widget(){
		$widget_ops = array('classname' => 'featured_sidebar', 'description' => 'Put a featured listing on sidebar.');
		$control_ops = array('id_base' => 'featured_widget');
		//$this->WP_Widget('featured_widget', 'Wp Estate: Featured Listing', $widget_ops, $control_ops);
                parent::__construct('featured_widget', 'Wp Estate: Featured Listing', $widget_ops, $control_ops);
	}
	
	function form($instance){
		$defaults = array(
                            'title'     =>  'Featured Listing',
                            'prop_id'   =>  ''
                    );
		$instance = wp_parse_args((array) $instance, $defaults);
		$display='<p>
			<label for="'.$this->get_field_id('prop_id').'">Property Id:</label>
		</p><p>
			<input id="'.$this->get_field_id('prop_id').'" name="'.$this->get_field_name('prop_id').'" value="'.$instance['prop_id'].'" />
		</p>';
		print $display;
	}


	function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['prop_id'] = $new_instance['prop_id'];
		return $instance;
	}



	function widget($args, $instance){
		extract($args);
                $display='';
		print $before_widget;
                $display.='<div class="featured_sidebar_intern">';
		
                $args=array( 
                            'post_type'         => 'estate_property',
                            'post_status'       => 'publish',
                            'p'                 =>  $instance['prop_id']
                            );
                $the_query = new WP_Query( $args );

                // The Loop
                while ( $the_query->have_posts() ) :
                        $the_query->the_post();
                        $link        =  esc_url ( get_permalink());
                        $prop_id     =    $instance['prop_id'];
                        $thumb_id    =  get_post_thumbnail_id($instance['prop_id']);
                        $preview     =  wp_get_attachment_image_src($thumb_id, 'property_listings');
                        $property_rooms         =   get_post_meta($prop_id, 'property_bedrooms', true);
                        if($property_rooms!=''){
                            $property_rooms=floatval($property_rooms);
                        }

                        $property_bathrooms     =   get_post_meta($prop_id, 'property_bathrooms', true) ;
                        if($property_bathrooms!=''){
                            $property_bathrooms=floatval($property_bathrooms);
                        }

                        $property_size          =   get_post_meta($prop_id, 'property_size', true) ;
                        if($property_size){
                            $property_size=wpestate_sizes_no_format(floatval($property_size));
                        }
                        
                        $wpestate_currency               =   esc_html( get_option('wp_estate_currency_symbol', '') );
                        $wpestate_where_currency         =   esc_html( get_option('wp_estate_where_currency_symbol', '') );
                        $price                  =   floatval   ( get_post_meta($prop_id, 'property_price', true) );
                        $price_label            =   esc_html ( get_post_meta($prop_id, 'property_label', true) );
                        $price                  =   wpestate_show_price($prop_id,$wpestate_currency,$wpestate_where_currency,1);  
                        
                        
                        $measure_sys            =   esc_html ( get_option('wp_estate_measure_sys','') ); 
                        $property_city          =   get_the_term_list($prop_id, 'property_city', '', ', ', '') ;
                        $property_area          =   get_the_term_list($prop_id, 'property_area', '', ', ', '');
                        
                        if($preview[0]==''){
                            $preview[0]= get_template_directory_uri().'/img/defaults/default_property_featured_sidebar.jpg';
                        }
                        
                        $agent_id       =   intval  ( get_post_meta($prop_id, 'property_agent', true) );
                        $thumbag_id       =   get_post_thumbnail_id($agent_id);
                        $agent_face     =   wp_get_attachment_image_src($thumbag_id, 'agent_picture_thumb');

                        if ($agent_face[0]==''){
                            $agent_face[0]= get_template_directory_uri().'/img/default-user_1.png';
                        }
                        
                        $display    .= '<div class="featured_widget_image" data-link="'.esc_url ( get_permalink()).'">
                                            <a href="'.esc_url ( get_permalink()).'"><img  src="'.$preview[0].'" class="img-responsive" alt="slider-thumb" /></a>
                                        </div>';
                        
                        $display    .=  '<div class="featured_widget_wrapper">';
                        $display    .=  '<div class="agent_image" style="background-image:url(' .$agent_face[0].')"></div>'; 
                        $display    .=  '<div class="featured_property_widget_price">'.$price.'</div>';
                        $display    .=  '<div class="featured_title"><a href="'.$link.'" class="featured_title_link">'.get_the_title().'</a></div>';

                        if( $property_city!='' || $property_area!='' ){
                            $display.= '<div class="property_location_wrapper">';
                            //$display.= '<i class="fa fa-map-marker"></i>';
                            if($property_area!=''){
                                $display.= $property_area.', ';
                            }
                            if($property_city!=''){
                                $display.= $property_city;
                            }
                    
                                $display.= '</div>';
                        }
                      
                                             
                        $display.= '<div class="property_listing_details">';

                        if($property_rooms!=''){
                            $display.= ' <div class="inforoom">'.$property_rooms.' <div class="info_labels">'.esc_html__('bedrooms','wpestatetheme-core').'</div></div>';
                        }

                        if($property_bathrooms!=''){
                            $display.= '<div class="infobath">'.$property_bathrooms.' <div class="info_labels">'.esc_html__('baths','wpestatetheme-core').'</div></div>';
                        }

                        if($property_size!=''){
                           $display.= ' <div class="infosize">'.$property_size.' '.$measure_sys.'<sup>2</sup> <div class="info_labels">'.esc_html__('size','wpestatetheme-core').'</div></div>';
                        }
                        $display.= '</div></div>';  
                endwhile;
                
                wp_reset_query();
		$display.='</div>';
		print $display;
		print $after_widget;
	 }




}

?>