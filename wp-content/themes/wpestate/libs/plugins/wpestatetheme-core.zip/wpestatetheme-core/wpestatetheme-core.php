<?php
/*
 *  Plugin Name: Wpestate -Theme Core Functionality
 *  Plugin URI:  https://themeforest.net/user/annapx
 *  Description: Adds functionality to WpEstate Theme
 *  Version:     5.2.1
 *  Author:      wpestate
 *  Author URI:  https://wpestate.org
 *  License:     GPL2
 *  Text Domain: wpestatetheme-core
 *  Domain Path: /languages
 * 
*/

define('WPESTATE_PLUGIN_URL',  plugins_url() );
define('WPESTATE_PLUGIN_DIR_URL',  plugin_dir_url(__FILE__) );
define('WPESTATE_PLUGIN_PATH',  plugin_dir_path(__FILE__) );
define('WPESTATE_PLUGIN_BASE',  plugin_basename(__FILE__) );

add_action( 'wp_enqueue_scripts', 'wpestate_theme_enqueue_styles' );
add_action( 'admin_enqueue_scripts', 'wpestate_theme_enqueue_styles_admin'); 
add_action( 'plugins_loaded', 'wpestate_theme_functionality_loaded' ); 
register_activation_hook( __FILE__, 'wpestate_theme_functionality' );
register_deactivation_hook( __FILE__, 'wpestate_theme_deactivate' );





function wpestate_theme_functionality_loaded(){
    $my_theme = wp_get_theme();
    $version = floatval( $my_theme->get( 'Version' ));

    if($version<5 && $version!=1){
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 'This plugin requires  WpEstate Theme 5.0 or higher.','wpestatetheme-core'); 
    }

    
    
    load_plugin_textdomain( 'wpestatetheme-core', false, dirname( WPESTATE_PLUGIN_BASE ) . '/languages' );
    wpestate_shortcodes();
    add_action('widgets_init', 'register_wpestate_widgets' );
    add_action('wp_footer', 'wpestate_core_add_to_footer');
    
}

function wpestate_theme_functionality(){
    wpestate_create_helper_content();   
}

function wpestate_theme_deactivate(){
}


function wpestate_theme_enqueue_styles() {
}


function wpestate_theme_enqueue_styles_admin(){
}


require_once(WPESTATE_PLUGIN_PATH . 'misc/metaboxes.php');
require_once(WPESTATE_PLUGIN_PATH . 'misc/plugin_help_functions.php');
require_once(WPESTATE_PLUGIN_PATH . 'misc/emailfunctions.php');
require_once(WPESTATE_PLUGIN_PATH . 'misc/3rd_party_code.php');

require_once(WPESTATE_PLUGIN_PATH . 'widgets.php');
require_once(WPESTATE_PLUGIN_PATH . 'shortcodes/shortcodes_install.php');
require_once(WPESTATE_PLUGIN_PATH . 'shortcodes/shortcodes.php');
require_once(WPESTATE_PLUGIN_PATH . 'post-types/agents.php');
require_once(WPESTATE_PLUGIN_PATH . 'post-types/invoices.php');
require_once(WPESTATE_PLUGIN_PATH . 'post-types/searches.php');
require_once(WPESTATE_PLUGIN_PATH . 'post-types/membership.php');
require_once(WPESTATE_PLUGIN_PATH . 'post-types/property.php');

require_once WPESTATE_PLUGIN_PATH.'resources/src/Google_Client.php';
require_once WPESTATE_PLUGIN_PATH.'resources/src/contrib/Google_Oauth2Service.php';

$facebook_status    =   esc_html( get_option('wp_estate_facebook_login','') );
if($facebook_status=='yes'){
    require_once WPESTATE_PLUGIN_PATH.'resources/facebook_sdk5/Facebook/autoload.php';
}
        

$enable_stripe_status   =   esc_html ( get_option('wp_estate_enable_stripe','') );
 
if($enable_stripe_status==='yes'){
    require_once(WPESTATE_PLUGIN_PATH.'resources/stripe/lib/Stripe.php');
}

$walkscore_api= esc_html ( get_option('wp_estate_walkscore_api','') );
if($walkscore_api!=''){
    require_once(WPESTATE_PLUGIN_PATH.'resources/WalkScore.php');
}

$yelp_client_id         =   get_option('wp_estate_yelp_client_id','');
$yelp_client_secret     =   get_option('wp_estate_yelp_client_secret','');

 if($yelp_client_id !=='' || $yelp_client_secret !=='' ){
    require_once(WPESTATE_PLUGIN_PATH.'resources/yelp_fusion.php');
}
$yahoo_status       =   esc_html( get_option('wp_estate_yahoo_login','') );
if($yahoo_status=='yes'){
    require_once(WPESTATE_PLUGIN_PATH.'resources/openid.php');
}

function wpestate_return_imported_data(){
    return  @unserialize(base64_decode( trim($_POST['import_theme_options']) ) );
}

function wpestate_return_imported_data_encoded($return_exported_data){
    return base64_encode( serialize( $return_exported_data) );
}



add_action( 'plugins_loaded', 'wpestate_check_current_user' );
function wpestate_check_current_user() {
    $current_user = wp_get_current_user();
    if (!current_user_can('manage_options') ) { 
        show_admin_bar(false); 
    }
}


function wpestate_create_helper_content(){
    
   
    if ( get_option('wpestate_theme_setup')!=='yes') {
    
        $page_check = get_page_by_title('Compare Listings');
        if (!isset($page_check->ID)) {
            $my_post = array(
                'post_title' => 'Compare Listings',
                'post_type' => 'page',
                'post_status' => 'publish',
            );
            $new_id = wp_insert_post($my_post);
            update_post_meta($new_id, '_wp_page_template', 'compare_listings.php');
        }
        
        
        ////////////////////  insert comapre and advanced search page 
        $page_check = get_page_by_title('Advanced Search');
        if (!isset($page_check->ID)) {
            $my_post = array(
                'post_title' => 'Advanced Search',
                'post_type' => 'page',
                'post_status' => 'publish',
            );
            $new_id = wp_insert_post($my_post);
            update_post_meta($new_id, '_wp_page_template', 'advanced_search_results.php');
        }
        
        ////////////////////  insert sales and rental categories 
        $actions = array(   'Rentals',
                            'Sales'
                        );

        foreach ($actions as $key) {
            $my_cat = array(
                'description' => $key,
                'slug' => $key
            );

            if(!term_exists($key, 'property_action_category') ){
                wp_insert_term($key, 'property_action_category', $my_cat);
            }
        }

        ////////////////////  insert listings type categories 
        $actions = array(   'Apartments', 
                            'Houses', 
                            'Land', 
                            'Industrial',
                            'Offices',
                            'Retail',
                            'Condos',
                            'Duplexes',
                            'Villas'
                        );

        foreach ($actions as $key) {
            $my_cat = array(
                'description' => $key,
                'slug' => str_replace(' ', '-', $key)
            );
        
            if(!term_exists($key, 'property_category') ){
                wp_insert_term($key, 'property_category', $my_cat);
            }
        }      
    }
    update_option('wpestate_theme_setup','yes');
}

add_action('wp_head', 'wpestate_add_custom_meta_to_header');

function wpestate_add_custom_meta_to_header(){
    global $post;
    
    if(is_singular('wpestate_invoice') || is_singular('wpestate_message')){
        print '<meta name="robots" content="noindex">';
    }
  
    
    if( is_tax() ) {
        echo '<meta name="description" content="'.strip_tags( term_description('', get_query_var( 'taxonomy' ) )).'" >';
    }
    
    if (get_post_type()== 'estate_property'){
        $image_id       =   get_post_thumbnail_id();
        $share_img= wp_get_attachment_image_src( $image_id, 'full'); 
        $the_post = get_post($post->ID);?>
        
        <meta property="og:image" content="<?php echo esc_url($share_img[0]); ?>"/>
        <meta property="og:image:secure_url" content="<?php echo esc_url($share_img[0]); ?>" />
        <meta property="og:description"        content=" <?php echo wp_strip_all_tags( $the_post->post_content);?>" />
        <?php 
    }   

    if(is_singular('wpestate_search') || is_singular('wpestate_invoice')){
        print '<meta name="robots" content="noindex">';
    }

    
}        



function noo_enable_vc_auto_theme_update() {
    if( function_exists('vc_updater') ) {
        $vc_updater = vc_updater();
        remove_filter( 'upgrader_pre_download', array( $vc_updater, 'preUpgradeFilter' ), 10 );
        if( function_exists( 'vc_license' ) ) {
            if( !vc_license()->isActivated() ) {
                    remove_filter( 'pre_set_site_transient_update_plugins', array( $vc_updater->updateManager(), 'check_update' ), 10 );
            }
        }
    }
}
add_action('vc_after_init', 'noo_enable_vc_auto_theme_update');


 function wpestate_compress($buffer) {
    $buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
    return $buffer;
}
?>